from django.apps import AppConfig


class ClipsConfig(AppConfig):
    name = 'clips'
