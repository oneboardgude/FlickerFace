from django.apps import AppConfig


class FunnyConfig(AppConfig):
    name = 'funny'
