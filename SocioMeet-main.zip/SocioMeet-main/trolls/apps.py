from django.apps import AppConfig


class TrollsConfig(AppConfig):
    name = 'trolls'
