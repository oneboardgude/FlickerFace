from django.apps import AppConfig


class InspiredConfig(AppConfig):
    name = 'inspired'
